package com.example.comandabar.utils

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun QrCodeVisual(
    data: String,
    modifier: Modifier = Modifier.size(200.dp)
) {
    Canvas(modifier = modifier) {
        // Limpar o canvas
        drawRect(Color.White, size = size)

        // Gerar padrão de QR Code simples
        generateSimpleQrPattern(data, size)
    }
}

private fun DrawScope.generateSimpleQrPattern(data: String, size: Size) {
    // Converter dados para hash simples
    val hash = data.hashCode()

    // Tamanho da grade (simples)
    val gridSize = 7
    val cellSize = size.width / gridSize

    // Desenhar quadrados dos cantos
    drawRect(
        color = Color.Black,
        topLeft = Offset(0f, 0f),
        size = Size(cellSize * 3, cellSize * 3)
    )

    drawRect(
        color = Color.Black,
        topLeft = Offset(size.width - cellSize * 3, 0f),
        size = Size(cellSize * 3, cellSize * 3)
    )

    drawRect(
        color = Color.Black,
        topLeft = Offset(0f, size.height - cellSize * 3),
        size = Size(cellSize * 3, cellSize * 3)
    )

    // Desenhar padrão baseado no hash
    for (i in 0 until gridSize) {
        for (j in 0 until gridSize) {
            // Pular os cantos
            if ((i < 3 && j < 3) ||
                (i >= gridSize - 3 && j < 3) ||
                (i < 3 && j >= gridSize - 3)) {
                continue
            }

            // Determinar se desenha quadrado baseado no hash
            val shouldDraw = ((hash + i * gridSize + j) % 3) == 0

            if (shouldDraw) {
                drawRect(
                    color = Color.Black,
                    topLeft = Offset(i * cellSize, j * cellSize),
                    size = Size(cellSize, cellSize)
                )
            }
        }
    }
}

// Componente mais simples para QR Code
@Composable
fun SimpleQrCode(
    text: String,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        // Fundo branco
        drawRect(Color.White, size = size)

        // Bordas pretas
        drawRect(
            color = Color.Black,
            size = size
        )

        // Fundo branco interno
        drawRect(
            color = Color.White,
            topLeft = Offset(5f, 5f),
            size = Size(size.width - 10f, size.height - 10f)
        )

        // Escrever texto no meio
        val displayText = if (text.length > 12) {
            text.take(12) + "..."
        } else {
            text
        }

        // Desenhar texto como padrão de pontos
        val gridSize = 5
        val cellSize = size.width / (gridSize + 2)

        for (i in 0 until gridSize) {
            for (j in 0 until gridSize) {
                val charIndex = (i * gridSize + j) % displayText.length
                val charCode = displayText[charIndex].code

                if (charCode % 2 == 0) {
                    drawRect(
                        color = Color.Black,
                        topLeft = Offset(
                            cellSize * (i + 1),
                            cellSize * (j + 1)
                        ),
                        size = Size(cellSize, cellSize)
                    )
                }
            }
        }

        // Marcadores dos cantos
        val markerSize = cellSize * 3
        drawRect(
            color = Color.Black,
            topLeft = Offset(cellSize / 2, cellSize / 2),
            size = Size(markerSize, markerSize)
        )

        drawRect(
            color = Color.Black,
            topLeft = Offset(size.width - markerSize - cellSize / 2, cellSize / 2),
            size = Size(markerSize, markerSize)
        )

        drawRect(
            color = Color.Black,
            topLeft = Offset(cellSize / 2, size.height - markerSize - cellSize / 2),
            size = Size(markerSize, markerSize)
        )
    }
}