package com.example.comandabar

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.navigation.compose.rememberNavController
import com.example.comandabar.bar.repository.ProdutoRepository
import com.example.comandabar.cliente.repository.ClienteRepository
import com.example.comandabar.navigation.NavGraph
import com.example.comandabar.shared.repository.ComandaRepository
import com.example.comandabar.ui.theme.ComandaBarTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar todos os repositórios
        ClienteRepository.init(this)
        ComandaRepository.init(this)
        ProdutoRepository.init(this) // Adicione esta linha!

        setContent {
            ComandaBarTheme {
                val navController = rememberNavController()
                NavGraph(navController)
            }
        }
    }
}