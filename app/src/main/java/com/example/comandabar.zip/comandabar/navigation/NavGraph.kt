package com.example.comandabar.navigation

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import com.example.comandabar.ui.HomeScreen
import com.example.comandabar.ui.menu.BarMenuScreen
import com.example.comandabar.ui.relatorios.RelatoriosScreen
import com.example.comandabar.bar.ui.produtos.ProdutosBarScreen
import com.example.comandabar.bar.ui.produtos.ProdutoFormScreen
import com.example.comandabar.bar.ui.comanda.ComandaBarScreen
import com.example.comandabar.bar.ui.comanda.GerarComandaScreen
import com.example.comandabar.bar.ui.comanda.ListaComandasScreen
import com.example.comandabar.bar.ui.comanda.VincularClienteComandaScreen
import com.example.comandabar.bar.ui.qrcode.QrCodeScreen
import com.example.comandabar.cliente.ui.home.ClienteHomeScreen
import com.example.comandabar.cliente.ui.home.ClienteFormScreen
import com.example.comandabar.cliente.ui.comanda.ClienteComandaScreen

@OptIn(ExperimentalAnimationApi::class)
@Composable
fun NavGraph(navController: NavHostController) {

    NavHost(
        navController = navController,
        startDestination = "home"
    ) {

        composable("home") {
            HomeScreen(navController)
        }

        composable("bar_menu") {
            BarMenuScreen(navController)
        }

        composable("produtos") {
            ProdutosBarScreen(
                onBack = { navController.popBackStack() },
                onAdicionarProduto = {
                    navController.navigate("produto_form")
                },
                onEditarProduto = { produtoId ->
                    navController.navigate("produto_form/$produtoId")
                }
            )
        }

        composable("produto_form") {
            ProdutoFormScreen(
                produtoId = null,
                onSalvar = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }

        composable(
            route = "produto_form/{produtoId}",
            arguments = listOf(
                navArgument("produtoId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val produtoId = backStackEntry.arguments?.getString("produtoId")

            ProdutoFormScreen(
                produtoId = produtoId,
                onSalvar = { navController.popBackStack() },
                onBack = { navController.popBackStack() }
            )
        }

        composable("clientes") {
            ClienteHomeScreen(navController)
        }

        composable("cliente_form") {
            ClienteFormScreen(
                navController = navController,
                clienteCodigo = null
            )
        }

        composable(
            route = "cliente_form/{clienteCodigo}",
            arguments = listOf(
                navArgument("clienteCodigo") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val clienteCodigo = backStackEntry.arguments?.getString("clienteCodigo")

            ClienteFormScreen(
                navController = navController,
                clienteCodigo = clienteCodigo
            )
        }

        composable("gerar_comanda") {
            VincularClienteComandaScreen(navController)
        }

        composable("comanda_produtos") {
            GerarComandaScreen(navController)
        }

        composable("lista_comandas") {
            ListaComandasScreen(navController)
        }

        composable("comanda_bar") {
            ComandaBarScreen(
                onBack = { navController.popBackStack() },
                navController = navController
            )
        }

        composable("relatorios") {
            RelatoriosScreen(navController)
        }

        composable("qrcode") {
            QrCodeScreen(navController)
        }

        composable("cliente_comanda") {
            ClienteComandaScreen(navController)
        }
    }
}