package com.example.comandabar.bar.model

enum class Categoria {
    CERVEJA,
    REFRIGERANTE,
    AGUA
}
