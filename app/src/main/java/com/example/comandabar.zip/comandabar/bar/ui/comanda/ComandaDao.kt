package com.example.comandabar.shared.repository

import android.content.Context
import com.example.comandabar.bar.model.Produto
import com.example.comandabar.cliente.viewmodel.Cliente
import com.example.comandabar.shared.model.Comanda
import com.example.comandabar.shared.model.ItemComanda
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.lang.reflect.Type

object ComandaDao {

    private const val PREFS_NAME = "comandas_prefs"
    private const val KEY_COMANDAS = "comandas"
    private const val KEY_COMANDA_ATIVA = "comanda_ativa"
    private const val KEY_COMANDA_SELECIONADA = "comanda_selecionada"

    @Volatile
    private var isInitialized = false
    private lateinit var context: Context
    private val gson = Gson()

    fun init(appContext: Context) {
        if (!isInitialized) {
            synchronized(this) {
                if (!isInitialized) {
                    context = appContext.applicationContext
                    isInitialized = true
                }
            }
        }
    }

    // Carregar todas as comandas - MÉTODO CORRIGIDO
    fun carregarComandas(): List<Comanda> {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandasJson = prefs.getString(KEY_COMANDAS, "[]") ?: "[]"

        return try {
            // Usando getType diretamente sem object expression para evitar problemas com R8
            val listType: Type = getComandaListType()
            val comandasDTO = gson.fromJson<List<ComandaDTO>>(comandasJson, listType) ?: emptyList()
            comandasDTO.map { it.toComanda() }
        } catch (e: Exception) {
            e.printStackTrace()
            emptyList()
        }
    }

    // Método seguro para obter o Type
    private fun getComandaListType(): Type {
        // Usando TypeToken.getParameterized que é mais seguro com R8/ProGuard
        return TypeToken.getParameterized(List::class.java, ComandaDTO::class.java).type
    }

    // Salvar todas as comandas
    fun salvarComandas(comandas: List<Comanda>) {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandasJson = gson.toJson(comandas.map { it.toComandaDTO() })
        prefs.edit()
            .putString(KEY_COMANDAS, comandasJson)
            .apply()
    }

    // Salvar comanda ativa
    fun salvarComandaAtiva(comanda: Comanda?) {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandaJson = if (comanda != null) gson.toJson(comanda.toComandaDTO()) else null
        prefs.edit()
            .putString(KEY_COMANDA_ATIVA, comandaJson)
            .apply()
    }

    // Carregar comanda ativa
    fun carregarComandaAtiva(): Comanda? {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandaJson = prefs.getString(KEY_COMANDA_ATIVA, null) ?: return null

        return try {
            val comandaDTO = gson.fromJson(comandaJson, ComandaDTO::class.java)
            comandaDTO?.toComanda()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // Salvar comanda selecionada
    fun salvarComandaSelecionada(comanda: Comanda?) {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandaJson = if (comanda != null) gson.toJson(comanda.toComandaDTO()) else null
        prefs.edit()
            .putString(KEY_COMANDA_SELECIONADA, comandaJson)
            .apply()
    }

    // Carregar comanda selecionada
    fun carregarComandaSelecionada(): Comanda? {
        ensureInitialized()

        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val comandaJson = prefs.getString(KEY_COMANDA_SELECIONADA, null) ?: return null

        return try {
            val comandaDTO = gson.fromJson(comandaJson, ComandaDTO::class.java)
            comandaDTO?.toComanda()
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private fun ensureInitialized() {
        if (!isInitialized) {
            throw IllegalStateException("ComandaDao não foi inicializado. Chame init() primeiro.")
        }
    }

    // Data Transfer Objects (mantenha como inner classes)
    private data class ComandaDTO(
        val id: String,
        val clienteCodigo: String,
        val clienteNome: String,
        val itens: List<ItemComandaDTO>,
        val status: String,
        val criadaEm: Long,
        val fechadaEm: Long? = null,
        val qrCodeData: String = ""
    )

    private data class ItemComandaDTO(
        val produtoId: String,
        val produtoNome: String,
        val produtoPreco: Double,
        val produtoEmoji: String,
        val produtoCategoria: String,
        val quantidade: Int = 1
    )

    // Conversão de Comanda para DTO
    private fun Comanda.toComandaDTO(): ComandaDTO {
        return ComandaDTO(
            id = id,
            clienteCodigo = cliente.codigo,
            clienteNome = cliente.nome,
            itens = itens.map { it.toItemComandaDTO() },
            status = status.name,
            criadaEm = criadaEm,
            fechadaEm = fechadaEm,
            qrCodeData = qrCodeData
        )
    }

    // Conversão de DTO para Comanda
    private fun ComandaDTO.toComanda(): Comanda {
        val cliente = Cliente(clienteCodigo, clienteNome)

        val itensConvertidos = itens.map { dto ->
            val produto = Produto(
                id = dto.produtoId,
                nome = dto.produtoNome,
                preco = dto.produtoPreco,
                emoji = dto.produtoEmoji,
                categoria = com.example.comandabar.bar.model.Categoria.valueOf(dto.produtoCategoria)
            )
            ItemComanda(produto, dto.quantidade)
        }

        return Comanda(
            id = id,
            cliente = cliente,
            itens = itensConvertidos,
            status = Comanda.Status.valueOf(status),
            criadaEm = criadaEm,
            fechadaEm = fechadaEm,
            qrCodeData = qrCodeData
        )
    }

    // Conversão de ItemComanda para DTO
    private fun ItemComanda.toItemComandaDTO(): ItemComandaDTO {
        return ItemComandaDTO(
            produtoId = produto.id,
            produtoNome = produto.nome,
            produtoPreco = produto.preco,
            produtoEmoji = produto.emoji,
            produtoCategoria = produto.categoria.name,
            quantidade = quantidade
        )
    }
}