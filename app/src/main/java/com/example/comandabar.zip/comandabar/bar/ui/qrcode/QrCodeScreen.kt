package com.example.comandabar.bar.ui.qrcode

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import androidx.navigation.NavController
import com.example.comandabar.shared.repository.ComandaRepository
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QrCodeScreen(
    navController: NavController
) {

    var qrCodeData by remember { mutableStateOf<String?>(null) }
    var isLoading by remember { mutableStateOf(false) }
    var showPermissionDialog by remember { mutableStateOf(false) }
    val context = LocalContext.current
    var comandaEncontrada by remember { mutableStateOf<com.example.comandabar.shared.model.Comanda?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text("Leitor de QR Code")
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Voltar"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(32.dp)
            ) {

                // Área de visualização da câmera/QR Code
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f)
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isLoading) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                CircularProgressIndicator()
                                Text("Escaneando...")
                            }
                        } else if (qrCodeData != null && comandaEncontrada != null) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    "✅",
                                    style = MaterialTheme.typography.displayMedium
                                )
                                Text(
                                    "Comanda Encontrada!",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                )
                                Text(
                                    "Cliente: ${comandaEncontrada?.cliente?.nome}",
                                    style = MaterialTheme.typography.bodyMedium
                                )
                            }
                        } else if (qrCodeData != null) {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    "❌",
                                    style = MaterialTheme.typography.displayMedium
                                )
                                Text(
                                    "Comanda não encontrada",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                )
                                Text(
                                    qrCodeData ?: "",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        } else {
                            Column(
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(16.dp)
                            ) {
                                Text(
                                    "📱",
                                    style = MaterialTheme.typography.displayLarge
                                )
                                Text(
                                    "Aponte a câmera para o QR Code da comanda",
                                    style = MaterialTheme.typography.bodyMedium,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                                Text(
                                    "O código será lido automaticamente",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                )
                            }
                        }
                    }
                }

                // Informações da comanda encontrada
                if (comandaEncontrada != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                "Comanda Encontrada!",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Cliente:")
                                Text(
                                    comandaEncontrada?.cliente?.nome ?: "",
                                    fontWeight = FontWeight.SemiBold
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Itens:")
                                Text("${comandaEncontrada?.itens?.size ?: 0}")
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Total:")
                                Text(
                                    "R$ ${"%.2f".format(comandaEncontrada?.total ?: 0.0)}",
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Status:")
                                Text(
                                    comandaEncontrada?.status?.name ?: "",
                                    color = if (comandaEncontrada?.status == com.example.comandabar.shared.model.Comanda.Status.ABERTA)
                                        Color.Green else Color.Red,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                }

                // Botões
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Button(
                        onClick = {
                            // Verificar permissão da câmera
                            if (hasCameraPermission(context)) {
                                iniciarEscaneamento()
                            } else {
                                showPermissionDialog = true
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        enabled = !isLoading
                    ) {
                        if (isLoading) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.Center
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Escaneando...")
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.CameraAlt,
                                    contentDescription = "Escanear"
                                )
                                Text("Escanear QR Code")
                            }
                        }
                    }

                    LaunchedEffect(isLoading) {
                        if (isLoading) {
                            delay(1500L)
                            isLoading = false
                            // Simular leitura de QR Code
                            val codigoSimulado = "COMANDA-${(1000..9999).random()}-CLI${(100..999).random()}"
                            qrCodeData = codigoSimulado

                            // Buscar comanda pelo QR Code
                            comandaEncontrada = ComandaRepository.getComandaPorQrCode(codigoSimulado)
                            if (comandaEncontrada == null) {
                                // Se não encontrar, criar uma comanda de exemplo para demonstração
                                comandaEncontrada = criarComandaDemonstracao(codigoSimulado)
                            }
                        }
                    }

                    if (qrCodeData != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    qrCodeData = null
                                    comandaEncontrada = null
                                },
                                modifier = Modifier.weight(1f),
                                enabled = !isLoading
                            ) {
                                Text("Nova Leitura")
                            }

                            if (comandaEncontrada != null) {
                                Button(
                                    onClick = {
                                        // Navegar para a tela de visualização da comanda do cliente
                                        ComandaRepository.selecionarComanda(comandaEncontrada!!.id)
                                        navController.navigate("cliente_comanda")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Receipt,
                                            contentDescription = "Ver Comanda"
                                        )
                                        Text("Ver Comanda")
                                    }
                                }
                            }
                        }
                    }
                }

                // Informações
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            "Como usar:",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                        Text(
                            "1. Peça ao funcionário o QR Code da sua comanda",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "2. Aponte a câmera para o código",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            "3. O sistema mostrará seus itens e o total",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    // Dialog de permissão
    if (showPermissionDialog) {
        AlertDialog(
            onDismissRequest = { showPermissionDialog = false },
            title = { Text("Permissão da Câmera Necessária") },
            text = {
                Text("Este aplicativo precisa de acesso à câmera para ler QR Codes. Por favor, permita o acesso nas configurações do dispositivo.")
            },
            confirmButton = {
                TextButton(
                    onClick = { showPermissionDialog = false }
                ) {
                    Text("OK")
                }
            }
        )
    }
}

// Função auxiliar para verificar permissão
private fun hasCameraPermission(context: Context): Boolean {
    return ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED
}

// Função auxiliar para iniciar escaneamento
private fun iniciarEscaneamento() {
    // Em uma implementação real, aqui iniciaria o leitor de QR Code
    // Por enquanto, apenas simula o processo
}

// Função para criar comanda de demonstração
private fun criarComandaDemonstracao(qrCode: String): com.example.comandabar.shared.model.Comanda {
    return com.example.comandabar.shared.model.Comanda(
        id = "demo-${System.currentTimeMillis()}",
        cliente = com.example.comandabar.cliente.viewmodel.Cliente(
            codigo = "CLI001",
            nome = "Cliente Demonstração"
        ),
        itens = listOf(
            com.example.comandabar.shared.model.ItemComanda(
                produto = com.example.comandabar.bar.model.Produto(
                    id = "p1",
                    nome = "Cerveja Pilsen",
                    preco = 8.50,
                    emoji = "🍺",
                    categoria = com.example.comandabar.bar.model.Categoria.CERVEJA
                ),
                quantidade = 2
            ),
            com.example.comandabar.shared.model.ItemComanda(
                produto = com.example.comandabar.bar.model.Produto(
                    id = "p2",
                    nome = "Água Mineral",
                    preco = 3.00,
                    emoji = "💧",
                    categoria = com.example.comandabar.bar.model.Categoria.AGUA
                ),
                quantidade = 1
            )
        ),
        status = com.example.comandabar.shared.model.Comanda.Status.ABERTA,
        criadaEm = System.currentTimeMillis(),
        qrCodeData = qrCode
    )
}